#!/usr/bin/python
import calendar, time;
 
#Get Epoch Time Format
etf = calendar.timegm(time.gmtime())
print(etf)