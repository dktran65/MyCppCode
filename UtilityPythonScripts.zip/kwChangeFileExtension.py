#!/usr/bin/env python

import os, sys, os.path
from fnmatch import fnmatch
from os.path import join

show_output = 1     # To displaydebug print out, set this to 1, otherwsie silent with 0


try:
    work_dir, old_ext, new_ext = sys.argv[1:]
except ValueError:
    sys.exit("Usage: {} directory old-ext new-ext".format(__file__))

for path, subdirs, files in os.walk(work_dir):
    for cur_name in files:
        if fnmatch(cur_name, ("*."+old_ext)):
            new_name = (os.path.splitext(cur_name)[0]+"."+new_ext)  # Rebuild filename with newfile extension
            if (show_output == 1):
                print os.path.abspath(path)
                print cur_name      # This print out the current filename with old extension
                print new_name      # This print out the current filename with new extension
            os.rename(join(os.path.abspath(path),cur_name), join(os.path.abspath(path),new_name))