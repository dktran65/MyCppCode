import os, sys;

if len(sys.argv) == 1: preTextMsg = ""
else: preTextMsg = sys.argv[1]
total_size = 0
start_path = '.'  # To get size of current directory
for path, dirs, files in os.walk(start_path):
    for f in files:
        fp = os.path.join(path, f)
        total_size += os.path.getsize(fp)
		
print(str(preTextMsg) + str(total_size/(1024000000)) + " GBytes (in " + str(total_size/(1024000)) + " MBytes), (in " + str(total_size) + " Bytes)") 
