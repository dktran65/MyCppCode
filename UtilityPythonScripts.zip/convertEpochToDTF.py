#!/usr/bin/python
import sys, datetime;

# Take one input: starting at arg[1]
etf = sys.argv[1]
# Convert the Epoch Time to human readable Date Time Format
dtf = datetime.datetime.fromtimestamp(float(etf)).strftime("%Y%m%d_%I%M%S")
print(dtf)
