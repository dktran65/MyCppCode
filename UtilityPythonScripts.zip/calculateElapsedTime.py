import os, sys;
from datetime import datetime

# Check to see if the last arugment preTextMsg argv=4 exist or not, if not then set it blank as text
if len(sys.argv) < 4: preTextMsg = ""
else: preTextMsg = sys.argv[3]
#get Epoch Time format
timeStart = long(sys.argv[1])
timeStop  = long(sys.argv[2])

#find the difference between two dates
duration = timeStop - timeStart
# print("duration in seconds: " + str(duration))
dd = duration/(24*60*60)
# print("No. of days: " + str(dd))
ddr = duration%(24*60*60)
# print("remainder for dd: " + str(ddr))
hh = ddr/(60*60)
# print("No. of Hours: " + str(hh))
hhr = ddr%(60*60)
# print("remainder for hhr: " + str(hhr))
mm = hhr/(60)
# print("No. of mins: " + str(mm))
mmr = hhr%(60)
# print("remainder for mmr: " + str(mmr))
ss = mmr
# print("No. of ss: " + str(ss))
print(str(preTextMsg) + "Time Duration is "+str(dd)+" day(s) "+str(hh)+" hr(s) "+str(mm)+" min(s) "+str(ss)+" sec(s) ")